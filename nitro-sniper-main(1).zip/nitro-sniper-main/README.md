<div align="center">
   <img src="/assets/banner.png" />
   <a href="https://github.com/slow"><img align="center" alt="Author" src="https://img.shields.io/static/v1?label=author&message=eternal&color=0d6ec9&style=for-the-badge&logo=data%3Aimage/png%3Bbase64%2CiVBORw0KGgoAAAANSUhEUgAAABQAAAATCAYAAACQjC21AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHpFAACAgwAA/FcAAIDoAAB5FgAA8QEAADtfAAAcheDStWoAAAD0SURBVHjarJQ9SoNBEEDfp00q8QoxQgoPYG1pkQPYWpgbWAvaWRm7NLlGUEEQFETwD8RCsLCMYK%2BQvDQRJNlvv93EB9vM7jx2Z4ZFJbJ21Qt1oH6ql2o7llO2sayeW86VWssRnlnNdaqwZTo70/lLzNImnb3pQEi4niFcSxEOM4TDFOFzhvBlJhJoymZGU7ZSx%2BY0QdbLmUPUTkTWLcsr1FiN6sA2sAEUwCvQB97KEqqEAKtAYyJ8B76ipwPXbqgH6p36HXjuj3qvHqnNqhoeqyPzOAkJa%2Bqt8/OkrvwV3rg4j7/Cff%2BPw0J9mHwIshgF8DEeAPZgZ0kPPubLAAAAAElFTkSuQmCC"></a>
   <a href="https://t.me/nitrosnipers"><img align="center" alt="Support" src="https://img.shields.io/badge/Support-Telegram-ffffff?color=0d6ec9&logoColor=white&style=for-the-badge&logo=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAaQSURBVHhe7ZpriFRlGMed2fVSpi7qpqXVSpFErbn4oWhZU9IKoki3DEnKLq6VWUj0JQr6UILYh0DogxZBYZERERGYQWtmFubCptJls0jKa5KXvaize2b7/c951hxnZmfOzJlzdrf5w4/znvfyvM/7nst7OWdYWWWVVVZZ/2PF7DhklUwmL+MwG1a6EZ52wsvxePyUdzqE1NvbO5xGT4G58Bp8StwJOCfiOpVmRQa/aFMcRtGo6+BpaIH9bmuziPS9Vnxwi7ZUwb006ANodVuXhwZ9B9CAOngYmq1NvjQoOwCnp8Ez8A3shx5wrE15izIJeEg2B/wogL8TYT7BGTAHamOx2GilFSrsJbBxG2wfcB2Ac8MhTnAmXAHLoA4m4nAg/mL/NId5DIM7BlQHcFtezmER1MJc2jtN8blEg3o5dEMnVOXqKLJ/yWExHXDUi4lQutowh8Y/CIfAgaQalY/IqvdAG6zl9H5IGfMzibzrrfrohB81ODIdtsBxzzV/otwf8DzBGtAE6FnochOziPRuWG1uhCfqjlHxeFgOr8KfcBJ8vcXJL6ncJ3AVUSM43gzroMPLlV3k+Rs0PQ5HVHYRNMB98C20my++RVldvZ/gHqgmSp06G1q8HLlF3qMw3twrjahHz/VkKqqFN+Eft/YCRXlJ83dd5XqrRp2rK+9n9ie1EawyE8EJozG4hApuhyfgGMjpvF9oF0plkSYtO0HP+sVWnRqvztXLz88LU3fQYjMRjLBbgdG+1dd26PSqK17Y0u26AKqtOlckzSRO7xBfnUt2dUCjmSlc2NKzVw260mvhLMh4wVf7fGFGQ5sWN3dbla5IqiSuHvaB77ooIj8XmDn/woaWnLfAMtgDZzzTxQtbkuYAeslpTE95TombcKbb2dDjOIe8Ev6Fja/B3zSacpWgZ3s+x00yVAphX++LlQRrrOpzIn4kvAcJL3dhovznZjI/UUbP2itwGAJ7tjNoK/Yfs2pTRPxo+AiKaryEjf47gAwas6eSdynHZtCLxtfUNF/JJjoCGyHjuKx4UOOL9oHimiTNM9PpIsNd8C6chh6vWGkk+/A63MipVn5pIm0C6LYPqvNPYEqry1RZRdpg0PTSlRUIXJjWlfwFXuC0wlxIE2lV5HkfArsQ2NIEaLJV8Z9IeAp876r4EfYlTWi+4HQyZLzqEnlWwFfK7xYOSNh70apIkRz5leVzu3cavKj7LIePYSH1LILDkHQTLxBOPs5BK7UGqFRcgHLsmCocjFPxA6Bx3X3puV1WpGQHfoM1nGrnNusmBWkaapvIewpK8cLVErnJqksXiVq8jCPjTbAaPgONy75nd8qPzoBWflrvj7RqMooiqtttvGugBMJ2ay4/UkTmMaAd2DWwF/JazZFPz/mPBJfCRDPXrxI9vU2Ok3sdX4zwqcWq8yfK6ur0zb+XwCpwt6Ih5c6wuPUwntOce43km+o4zlvQTgeUcuSR7V1WbeHCiJa76gzdGVrybgDNrSXdJfWkj7Ps/Yq8tTT8B2Bq75Ss8RJ1dcGdVnUwwq7uDC2MroZGqOM8rx1m8s0iv77dlXTo7RP16PGaZdVHKzkCu+RYWKIDtJky1VxIU9YJSdDCiRvw522CYV+N7+Px+F8WTlMoHUDjr+fwIRMgffAYUCp5B9D4sRzegOluRIjijuvgsMc7y6ww7gDt503h6kfxGe4IbPKCmRVGByyEK71g6Oql3xMWzqgwOmAsTgy3cGjSAEC9BwhmXHj1KZSXYETScnodndBl5xk1lDsgLw2IDuBKHYRjdhqIWLB0djmO/hfoV5F2AI2WdhNcAisIH4ZuRboZilBFLLbjZGXlNjvNqsg6wBq5D5YzU2uGTTyv+m73DpwuphNUVs8+Y2+/z78UegfIOaSh6XdopOHfuQkIp7dyrm2xjeB+RncT/EsToJxXX4riDtAPStqgbKCx2WZpq+AOaHXP/Et7nFu8YIRiGjwJdrrXHBHWnp8al5fIOyPR7bQ6jtNBOO99A7IegGvMTHTCiWtBGxJyXh8m9I1/hCXnpfZk8lLK6Sv0QXBfkLlEvs0wyUxEJ5xQB2hz9Tg8h28Fb3VTXtty+lKU84s0ec7/NT464Yj+IdAPUY/iV9GLIezobtDnu6x/nhCtPcsnrcjQE23U9v2toF/k0jqBqN0Q/e1fatFWfbr/Gc59QiMsbSM4yrLlVBRr9MBEY8dweAT0E7Wk32VfYnht807LKqusssoqK7uGDfsXLk2MHvkgcdcAAAAASUVORK5CYII="></a>
   <a href="https://github.com/slow/nitro-sniper/stargazers"><img align="center" alt="Stars" src="https://img.shields.io/github/stars/slow/nitro-sniper?color=0d6ec9&style=for-the-badge&logo=data%3Aimage/png%3Bbase64%2CiVBORw0KGgoAAAANSUhEUgAAAB4AAAAdCAYAAAC9pNwMAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHpFAACAgwAA/FcAAIDoAAB5FgAA8QEAADtfAAAcheDStWoAAAHISURBVHjavJS/a1NRGIafm7RaaGJ1KR0MQUVNBiOhtKLg6GKXItRJVwc3M%2BpW%2Bg/4Fwid3LRLBydBHARBiqSiqcY2UOgipopBQnxdzpXr5dyb5iQnHxw49/z4nvOe7543kIRjPAFywIrL5sARPAF0TT8P/Bw0QcZR7cNIf3VcirNG4ZT5/mOuvONb8YMINMzxyLfiLNAGpmPjPVPrji/F9y3Q8EA1n4oPgNmEuUNgxofitRQowAng8bCKTwFF4CxQBq4BN4%2BY8wXwCvgAfAb2gG828C3gDHDOgIpAIaGWLvELaAG7QBNoAF8DSV8MeJxxkAEWgfoYoU1gPqzxceANcNkztAEsAO3wr/5tBt55hH4C5o0B/fecusBVT/CPpqQ//o1IircJSW81utiWlItzkt5xAGwBl4ZUugNUbB6eZplFU5djjtAeUAXeu3h1CzjtCG4DJ128eq6PN/eLPHDeBVwd4prD3FUXcGkEz%2BiCC/jiCMAlH%2BAN4JmrYpuBhG0/wRCeSqpE1pUkrSes/S5p0pY/CVqwJNmUdD3loFckPbfsKw8CXo5sfC1pKQUYbzckvYzsvzMI%2BJ7x2LsDAOPttqS6pJpt/u8AK65O%2Bt9ReEMAAAAASUVORK5CYII%3D"></a>
   <a href="https://paypal.me/eternal404"><img align="center" alt="PayPal" src="https://img.shields.io/badge/PayPal-Donate-ffffff?color=0d6ec9&style=for-the-badge&logo=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAgCAYAAAABtRhCAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAdhwAAHYcBj+XxZQAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAIZSURBVEiJvZa7a1RREIe/CRsIqBBQJEEUO5+YRgSx0JTBwkKwsBMU/4HY2dmKFmm1tRBREEGFYGMhvgolPlBsRBuJj5iIiRvzWWxuOF7v3r2Ld/ODhXNmhvnOzHnshZzU82rTamqqn9XX6jV1XB3K52wrtaHOV4S104J6Ue2vAtz2n7BUt9S+PCNv2FG5HZ11GDi1mkCA052AO2sG7s63tdcV9gON1BDZQA1gFlhTI3AmIgZTQ1rhlpphAFN5Qwqse/8A7uYNaX/r3j+Am9lAHQbmegmcjIhnyfwosLFXwEXgbM52BBhemdl6hOvSeEpSR9QldTYzDNUE+q2eyZer3lj2rwBHa4A9UA8UwE4kMS+yPexm/xZpPRDTwBvgCXA9Ip4XwEaBicT0MHNMlKz8ijrQxYKynMfVn7lcxzLnZAnwYJegEfV2QZ6P6kDW0rJX5lUHwAZgD7CP1l3b2yb0XETMow6WVDedS35Bfbf8+2LrqFfRVVt/DqDuLwm8nwM+qghIdcnk+6aP8hO60s7lFW4va2+iReAOcCgiTkZEM3M0OgBfJuNNwLqCmHvAY+AbMAO8BZ5GxNeihA2qH5iiuO/AWET8Ksnxl/o6ANMKizox1Q0sA65t45sDPiTzov0rvTJFagC7gM0FvoWIMJkXVdg1sLLUTwVHfqxXsPVt7tjWbnP98+3fRkXt/AG8Xy3gEnA5Ipa6Bf4BbzmPtw84RMAAAAAASUVORK5CYII="></a>
</div>

---

<h3 align="center">Discord Sniper</h3>

<p align="center">A lightweight, fast and efficient Discord Nitro sniper, giveaway sniper & invite sniper.</p>

---

# Features

- Nitro, giveaway & invite sniper
- Customizable limits for the sniper (e.g. Snipe 2 Nitros then stop for 24 hours)
- Light, fast & efficient
- Customizable delay for giveaway joiner
- DMing the host on giveaway win with customizable DM Delay and a DM Message.
- Status changer for main account & alternate accounts
- Fake code & duplicate protection
- Multi-Account support featuring alternate accounts & main accounts
- 3 Modes - `main`, `alts`, `both`. Each mode describes what accounts will be used when the sniper starts.
- Feeding system from alternate accounts, catches a nitro on your alternate account and redeems it on your main account
- Customizable webhook (Giveaways, Nitro, invites) with customizable events (Invalid Code, redeemed code, joined server)
- Customizable webhook mentions for fired events (Pings @everyone, recommended to run in a private server)
- Fully customizable word whitelist & blacklist for the giveaway sniper.
- Whitelist only mode for giveaway sniper (Blacklist still applies)
- Per-server blacklist and whitelist for the giveaway sniper
- Announces the type of Nitro sniped on snipe (e.g. Nitro Classic)
- Configurable invite sniper featuring minimum and max member counts and limited invite joins (e.g. 10 invites / 6 hours)
- Delay management for the invite sniper to avoid suspensions

## Previews
![Image](https://media.wtf/11603354)

## FAQ
- **Q: Where can I find the installation steps?**
- A: [Installation](https://github.com/slow/nitro-sniper/wiki/Installation)

<br />

- **Q: Where can I find the default configuration?**
- A: [Default Configuration](https://github.com/slow/nitro-sniper/wiki/Default-Configuration)

<br />

- **Q: How can I obtain my token?**
- A: [How to obtain your token](https://www.youtube.com/watch?v=rawcwqFJCCE)

<br />

- **Q: I'm getting the `Invalid Settings` error, how can I fix this?**
- A: [Validate your JSON5](https://jsonformatter.org/json5-validator)

## Tips

- Try to get a low latency to Discord servers as there often is competition with other snipers.
- This is technically a self-bot: mentioning this in a Discord chat is enough to make your account reportable to Trust & Safety.
- Running more than one instance or different snipers is an easy way to get your account deactivated or terminated.
- Before using, consider the moral implications of stealing gifts from people and communities you have nothing to do with.

> If you enjoy my projects, please consider leaving a :star: in the top right on the repo :)
